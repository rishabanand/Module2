package com.cg.mobilepur.ui;

import java.util.ArrayList;
import java.util.Scanner;
import com.cg.mobilepur.bean.Mobile;
import com.cg.mobilepur.bean.MobilePurchase;
import com.cg.mobilepur.exception.MobileException;
import com.cg.mobilepur.service.MobileService;
import com.cg.mobilepur.service.MobileServiceImpl;

public class TestMobileClient
{
	static Scanner sc=null;
	static MobileService mobSer=null;
	public static void main(String[] args) 
	{
		mobSer=new MobileServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("What Do You Want To Do? ");
			System.out.println("1:Add Customer Purchase Details \nAnd Update the Mobile Quantity"
					+ "\n2.Fetch All Mobile Details\n3.Delete A Mobile detail  based on Id "
					+ "\n4.Fetch MobilesInfo Based Price\n5.Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: insertCustPurDetail();
					updateMobileQuantity();
						break;
			case 2: fetchAllMobInfo();
					break;
			case 3:deleteMobInfoById();
					break;
			case 4:	fetchMobInfoByPrice();
					break;
			default: exit();

			}
		}
	}
	/**********************Main Ends**************/
	public static void insertCustPurDetail()
	{		
		int dataAdded=0;
		
		System.out.println("Enter Customer Name :");
		String cnm=sc.next();
		try
		{
			MobilePurchase mobPur=null;
			if(mobSer.validateName(cnm))
			{
				System.out.println("Enter Mail Id :");
				String mailId=sc.next();
				if(mobSer.validMailId(mailId))
				{
					System.out.println("Enter Phone Number :");
					String phNo=sc.next();
					if(mobSer.validPhoneNo(phNo))
					{
						System.out.println("Enter Mobile Id:");
						int mobId=sc.nextInt();
						if(mobSer.validMobileId(mobId))
						{
							if(mobSer.validQuantity(mobId))
							{
								mobPur=new MobilePurchase();
								mobPur.setCustomerName(cnm);
								mobPur.setMailId(mailId);
								mobPur.setPhoneno(phNo);
								mobPur.setMobileId(mobId);

								dataAdded=mobSer.addCustPurDetails(mobPur);
								
								if(dataAdded==1)
								{
									System.out.println("Customer Purchase Info Added");

								}
								else
								{
									System.out.println("May some Exception while inserting");
								}
							}

						}
					}
				}
			}
		}
		catch (MobileException e) 
		{
			System.out.println(e.getMessage());
		}
}
	public static void updateMobileQuantity() 
	{
		int mobId=0;
		int newQuan=0;
		int dataUpdated=0;
		
		System.out.println("Enter the  New Quantity");
		newQuan=sc.nextInt();
		System.out.println("Enter the mobileId");
		mobId=sc.nextInt();
		try 
		{
			if(mobSer.validMobileId(mobId))
			{
				dataUpdated=mobSer.updateMobQuanty(newQuan, mobId);
				if(dataUpdated==1)
				{
					System.out.println(" Mobile Quantity Updated successfully");
				}
				else
				{
					System.out.println("May Some Exception While Updating");
				}
			}
		} 
		catch (MobileException e)
		{
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	

	public static void fetchAllMobInfo() 
	{
		try 
		{
			ArrayList<Mobile> mobList=mobSer.getAllMobileDetails();
			for(Mobile m:mobList)
			{
				System.out.println(m);
			}
		} 
		catch (MobileException e)
		{
			System.out.println("May some Exception while addition");
		}

	}
	public static void deleteMobInfoById() 
	{
		System.out.println("Enter MobileId :");
		int mobId=sc.nextInt();

		try 
		{
			if(mobSer.validMobileId(mobId))
			{

				int dataDeleted=mobSer.deleteMobDetailById(mobId);
				if(dataDeleted==1)
				{
					System.out.println("Deletd the record successfully");
				}
				else
				{
					System.out.println("May some Exception while inserting");
				}

			}
		} 
		catch (MobileException e) 
		{
			System.out.println(e.getMessage());
		}

	}

	public static void fetchMobInfoByPrice() 
	{
		System.out.println("Enter Minimum Price");
		float minPrice=sc.nextFloat();
		System.out.println("Enter Maximum Price");
		float maxPrice=sc.nextFloat();
		try 
		{
			
			ArrayList<Mobile> mobList=mobSer.getMobDetailsByPrice(minPrice, maxPrice);
			for(Mobile m:mobList)
			{
				System.out.println(m);
			}
		} 
		catch (MobileException e)
		{

			System.out.println(e.getMessage());
		}

	}
	public static void exit()
	{
		System.exit(0);

	}

}
