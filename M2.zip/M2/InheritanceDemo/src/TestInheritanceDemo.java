
public class TestInheritanceDemo
{
	public static void main(String[] args) 
	{
		Employee rishab = new Employee(101,"rishab",2000.0f);
		WageEmp divya = new WageEmp(102,"divya",1000.0f,400,5);
		
		System.out.println("Emp Info: "+rishab.dispEmpInfo());
		System.out.println("Emp Monthly sal: "+rishab.calcEmpBasicSal());
		System.out.println("Emp Annual sal: "+rishab.calcEmpAnnualSal());
		
		System.out.println("Wage Emp Info: "+divya.dispEmpInfo());
		System.out.println("Wage Emp Monthly sal : "+divya.calcEmpBasicSal());
		System.out.println("Wage Emp Annual salary: "+divya.calcEmpAnnualSal());
		
		Employee shushant = new WageEmp(103,"Shushant",1000.0f,400,7);
		System.out.println("Wage Emp Info: "+shushant.dispEmpInfo());
		System.out.println("Wage Emp Monthly sal : "+shushant.calcEmpBasicSal());
		System.out.println("Wage Emp Annual salary: "+shushant.calcEmpAnnualSal());
		
		SalesManager raj = new SalesManager(103,"Raj",1000.0f,5,50,10,100.0f);
		System.out.println("Sales Emp Info"+raj.dispEmpInfo());
		System.out.println("Sales Monthy sal:"+raj.calcEmpBasicSal());
		System.out.println("Sales Annual Salary"+raj.calcEmpAnnualSal());
		
	}
}
