
public class SalesManager extends WageEmp 
{
	private int sale;
	private float comm;
	public SalesManager() 
	{
		super();
	}
	public SalesManager(int empId, String empName, float empSal, int noOfHrs,
			int ratePerHrs,int sale,float comm) 
	{
		super(empId, empName, empSal, noOfHrs, ratePerHrs);
		this.sale = sale;
		this.comm = comm;
	}
	 public float calcEmpBasicSal()
	 {
		 return super.calcEmpBasicSal()+(comm*sale*22);
	 }
	 public float calcEmpAnnualSal()
	 {
		 return calcEmpBasicSal()*12;
	 }
}

