import java.util.Scanner;


public class TestObjectArray 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of  Employees");
		int empCount = sc.nextInt();
		Employee empArr[]=new Employee[empCount];
		int eId=0;
		String enm = null;
		float esl=0.0f;
		int noOfHours=0;
		int ratePerHrs=0;
		int sale=0;
		float comm=0.0f;
		for(int i=0;i<empArr.length;i++)
		{
			System.out.println("Enter Emp Id:");
			eId=sc.nextInt();
			System.out.println("Enter Emp Name: ");
			enm=sc.next();
			System.out.println("Enter Emp Salary");
			esl=sc.nextFloat();
			System.out.println("Choose Type of Employee for"+enm+"1.Emp\t2:wageEmp\t3.Sales Manager");
			System.out.println("Enter Choice");
			int choice=sc.nextInt();
			
			switch(choice)
			{
			case 1:
				empArr[i]=new Employee(eId,enm,esl);
				break;
			case 2:
				System.out.println("Enter No Of hrs U worked");
				noOfHours=sc.nextInt();
				System.out.println("Enter Rate per hour");
				ratePerHrs=sc.nextInt();
				empArr[i]=new WageEmp(eId,enm,esl,noOfHours,ratePerHrs);
				break;
			default:
				System.out.println("Enter No Of hrs U worked");
				noOfHours=sc.nextInt();
				System.out.println("Enter  rate per hour");
				ratePerHrs=sc.nextInt();
				System.out.println("Enter the sales count ");
				sale=sc.nextInt();
				System.out.println("Enter  commission ");
				comm=sc.nextFloat();
				empArr[i]=new SalesManager(eId,enm,esl,noOfHours,ratePerHrs,sale,comm);
				 
			}
		}
		System.out.println("**********************************");
		for(int j=0;j<empArr.length;j++)
		{
			if(empArr[j] instanceof SalesManager)
			{
				System.out.println(" SalesManager :"+empArr[j].dispEmpInfo());
				System.out.println("Monthly Basic Employee: "+empArr[j].calcEmpBasicSal());
				System.out.println("Anaual Salary :"+empArr[j].calcEmpAnnualSal());
			}
			else if(empArr[j] instanceof WageEmp)
			{
				System.out.println("WageEmp  :"+empArr[j].dispEmpInfo());
				System.out.println("Monthly Basic Employee: "+empArr[j].calcEmpBasicSal());
				System.out.println("Anaual Salary :"+empArr[j].calcEmpAnnualSal());
			}
			else
			{
				System.out.println("Employee  :"+empArr[j].dispEmpInfo());
				System.out.println("Monthly Basic Employee: "+empArr[j].calcEmpBasicSal());
				System.out.println("Anaual Salary :"+empArr[j].calcEmpAnnualSal());
			}
		}
	}

}
