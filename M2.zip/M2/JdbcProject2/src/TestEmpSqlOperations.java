import java.sql.*;
import java.util.Scanner;


public class TestEmpSqlOperations
{
	public static void main(String[] args)
	{
		Connection con=null;
		PreparedStatement pst=null;
		Statement st=null;
		ResultSet rs= null;
		int dataAdded=0;
		int dataDeleted=0;
		int dataUpdated=0;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		} 
		catch (Exception e1) 
		{			
			e1.printStackTrace();
		}
		Scanner sc=new Scanner(System.in);
		System.out.println("Choose 1.Insert\n2.Delete\n3.Update\n4.Fetch All Data\n5.Fetch Particular Record\n6.Exit");
		System.out.println("Enter your Choice");
		int choice=sc.nextInt();

		switch(choice)
		{
		case 1:
			System.out.println("Enter the no of recors you want to insert");
			int noOfRecords=sc.nextInt();

			String insertQry="INSERT INTO emp_142270(emp_id,emp_name,emp_sal) VALUES(?,?,?)";
			for(int i=0;i<noOfRecords;i++)
			{			
				System.out.println("Enter Employee Id :");
				int empId=sc.nextInt();
				System.out.println("Enter Employee Name :");
				String empName=sc.next();
				System.out.println("Enter Employee Salary");
				float empSal=sc.nextFloat();


				try 
				{
					pst=con.prepareStatement(insertQry);
					pst.setInt(1, empId);
					pst.setString(2, empName);
					pst.setFloat(3, empSal);
					dataAdded=pst.executeUpdate();				
				} 
				catch (Exception e) 
				{					
					e.printStackTrace();
				}
			}
			System.out.println("Data Added "+dataAdded);
			break;
		case 2:
			System.out.println("Enter the no of recors you want to delete");
			int noOfRecord=sc.nextInt();
			String deletQry="Delete from emp_142270 where emp_id=?";
			for(int i=0;i<noOfRecord;i++)
			{			
				System.out.println("Enter Employee Id of the record which you want to delete:");
				int empId=sc.nextInt();

				try 
				{
					pst=con.prepareStatement(deletQry);
					pst.setInt(1, empId);
					dataDeleted=pst.executeUpdate();
				} 
				catch (Exception e) 
				{					
					e.printStackTrace();
				}

			}
			System.out.println("Data Deleted ");
			break;
		case 3:
			System.out.println("Enter the no of records you want to Update");
			int noOfRec=sc.nextInt();
			System.out.println("Choose 1.To Update the Sal \n2.To Update the Name ");
			int ch=sc.nextInt();
			if(ch==1)
			{

				System.out.println("Enter the new Salary");
				float esl=sc.nextFloat();
				String UpdateQry="UPDATE emp_142270 SET emp_sal=? WHERE emp_id=?";
				for(int i=0;i<noOfRec;i++)
				{			
					System.out.println("Enter Employee Id of the record for which you want to Update Salary:");
					int empId=sc.nextInt();

					try 
					{
						pst=con.prepareStatement(UpdateQry);
						pst.setFloat(1,esl);
						pst.setInt(2, empId);
						dataUpdated=pst.executeUpdate();
					} 
					catch (Exception e) 
					{					
						e.printStackTrace();
					}
				}
				System.out.println("Salary Updated ");
			}
			else
			{

				System.out.println("Enter the New Name :");
				String newName=sc.next();
				String UpdateQry="UPDATE emp_142270 SET emp_name=? WHERE emp_id=?";
				for(int i=0;i<noOfRec;i++)
				{			
					System.out.println("Enter Employee Id of the record for which you want to Update Name:");
					int empId=sc.nextInt();

					try 
					{
						pst=con.prepareStatement(UpdateQry);
						pst.setString(1, newName);
						pst.setInt(2,empId);
						dataUpdated=pst.executeUpdate();
					} 
					catch (Exception e) 
					{					
						e.printStackTrace();
					}
				}
				System.out.println("Name Updated ");
			}
			break;
		case 4:
			try 
			{
				st=con.createStatement();
				rs=st.executeQuery("SELECT * FROM emp_142270");
				System.out.println("Id\t Name\tSalary\tDOJ");
				while(rs.next())
				{		
					System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getInt("emp_sal")+"\t"+rs.getDate("emp_doj"));
				}
			}	
			catch (Exception e)
			{
				e.printStackTrace();
			}
			break;
		case 5:
			System.out.println("Enter the no of recors you want to Select");
			int noOfRecor=sc.nextInt();

			String selectQry="Select * from emp_142270 where emp_id=?";
			for(int i=0;i<noOfRecor;i++)
			{			
				System.out.println("Enter Employee Id of the record which you want to Select:");
				int empId=sc.nextInt();

				try 
				{
					pst=con.prepareStatement(selectQry);
					pst.setInt(1, empId);
					rs=pst.executeQuery();

					System.out.println("Id\t Name\tSalary\tDOJ");
					while(rs.next())
					{		
						System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getInt("emp_sal")+"\t"+rs.getDate("emp_doj"));
					}
				} 
				catch (Exception e) 
				{					
					e.printStackTrace();
				}
			}
			break;
		default:
			System.exit(0);
	
		}
	}
}
