package com.cg.eis.pl;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;
import java.util.*;
public class TestEmployeeInfo 
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Employee Id :");
		int empId=sc.nextInt();
		System.out.println("Enter the Employee Name :");
		String enm=sc.next();
		System.out.println("Enter the employee Salary :");
		double esl=sc.nextDouble();
		System.out.println("Enter the designation :");
		String eDes=sc.next();
		Service s=new Service();
		Employee e=new Employee(empId,enm,esl,eDes,s);
		System.out.println(e);
	}
}
