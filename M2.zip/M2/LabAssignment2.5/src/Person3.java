
public class Person3 
{
	private String firstName;
	private String lastName;
	private Gender gender;
	private String phoneNumber;
	
	public Person3()
	{
		
	}
	public Person3(String firstName,String lastName,Gender gender,String phoneNumber )
	{
		setFirstName(firstName);
		setLastName(lastName);
		setGender(gender);
		setPhoneNumber(phoneNumber);
	}
	public String getFirstName()
	{
		return firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public Gender getGender()
	{
		return gender;
	}
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	public void setGender(Gender gender)
	{
		this.gender = gender;
	}
	public void setPhoneNumber(String phoneNumber)
	{
		 this.phoneNumber = phoneNumber;
	}
	public void displayPerson3()
	{
		System.out.print("Person Details");
		System.out.println("\n______________");
		System.out.println("Employee Id :"+firstName);
		System.out.println("Employee Name :"+lastName);
		System.out.println("Employee Salary :"+gender);
		System.out.println("Employee Gender :"+phoneNumber);
	}
}
