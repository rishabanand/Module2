
public enum Gender 
{
	Male,Female
}
