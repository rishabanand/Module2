import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class TestStreamAPIDemo 
{
	public static void main(String[] args)
	{
		List<String> cityList=Arrays.asList("Pune","Mumbai","Nagpur","Gaziabad","Mumbai");
		cityList.stream().distinct().forEach(System.out::println);
		System.out.println("***********");
		Long cityCount=cityList.stream().distinct().count();
		System.out.println("How Many Cities ? "+cityCount);
		System.out.println("**********");
		cityList.stream().distinct().map(str->str.length()).forEach(System.out::println);
		System.out.println("**************");
		long emptyStrCont=cityList.stream().filter((String str)->str.isEmpty()).count();
		System.out.println("Empty String : "+emptyStrCont);
	}

}
