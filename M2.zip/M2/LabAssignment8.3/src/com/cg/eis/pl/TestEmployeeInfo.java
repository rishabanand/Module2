package com.cg.eis.pl;
import com.cg.eis.bean.*;
import com.cg.eis.service.*;
import com.cg.eis.exception.*;

import java.util.*;
public class TestEmployeeInfo 
{
	public static void main(String[] args) 
	{
		int empId=0;
		String enm=null;
		double esl=0;
		String eDes=null;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the no of Objects");
		int noOfOb=sc.nextInt();
		for(int i=0;i<noOfOb;i++)
		{
		System.out.println("Enter the Employee Id :");
		 empId=sc.nextInt();
		System.out.println("Enter the Employee Name :");
		 enm=sc.next();
		System.out.println("Enter the employee Salary :");
		 esl=sc.nextDouble();
		System.out.println("Enter the designation :");
		 eDes=sc.next();
		}
		Service s=new Service();
		Employee e=new Employee(empId,enm,esl,eDes,s);
		System.out.println(e);
		s.serialiazation(e, noOfOb);
		if(esl<3000)
		{
			try
			{
				throw new EmployeeException("Not valid Salary");
			} 
			catch (EmployeeException e1) 
			{				
				System.out.println("Salary Must be above 3000");
			}
		}
		else
		{
			System.out.println("Valid Salary");
		}
		
	}
}
