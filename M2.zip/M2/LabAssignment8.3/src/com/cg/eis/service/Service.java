package com.cg.eis.service;
import com.cg.eis.bean.*;

import java.io.*;

public class Service implements EmployeeInterface,Serializable
{
	
	public String calInsuranceScheme(double salary,String designation)
	{
		String insScheme=null;
		if(salary>5000 && salary<20000  && designation.compareTo("SystemAssociate")==0)
		{
			 insScheme="SchemeC";
		}
		else if(salary>=20000 && salary<40000 && designation.compareTo("Programmer")==0)
		{
			 insScheme="SchemeB";
		}
		else if(salary>=40000 && designation.compareTo("Manager")==0)
		{
			 insScheme="SchemeA";
		}
		else if(salary<5000  && designation.compareTo("Clerk")==0)
		{
			 insScheme="No Scheme";
		}
		
		return insScheme;
	}
	public void serialiazation(Employee emp,int noOfObjects)
	{
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		try 
		{
			 fos=new FileOutputStream("EmpData.obj");
			 oos=new ObjectOutputStream(fos);
		} 
		catch (Exception e2) 
		{

			e2.printStackTrace();
		}
		
		
		for(int i=0;i<noOfObjects;i++)
		{			
			try 
			{
				oos.writeObject(emp);
				System.out.println("Emp Object is written in a file");
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
		System.out.println("Record Added into EmpInfo.txt");
	}
}
