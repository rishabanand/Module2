import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;


public class TestEmpSelectDemo2 
{
	public static void main(String[] args)
	{
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		Scanner sc=sc=new Scanner(System.in);
		int dataUpdated=0;
		System.out.println("Enter the no of recors you want to Select");
		int noOfRecords=sc.nextInt();
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		} 
		catch (Exception e1) 
		{			
			e1.printStackTrace();
		}
		String selectQry="Select * from emp_142270 where emp_id=?";
		for(int i=0;i<noOfRecords;i++)
		{			
			System.out.println("Enter Employee Id of the record which you want to Select:");
			int empId=sc.nextInt();

			try 
			{
				pst=con.prepareStatement(selectQry);
				pst.setInt(1, empId);
				rs=pst.executeQuery();
				
				System.out.println("Id\t Name\tSalary\tDOJ");
				while(rs.next())
				{		
					System.out.println(rs.getInt("emp_id")+"\t"+rs.getString("emp_name")+"\t"+rs.getInt("emp_sal")+"\t"+rs.getDate("emp_doj"));
				}
			} 
			catch (Exception e) 
			{					
				e.printStackTrace();
			}
		}
		

	}

}
