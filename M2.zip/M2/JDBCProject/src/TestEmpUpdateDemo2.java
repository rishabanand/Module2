import java.sql.*;
import java.util.Scanner;

public class TestEmpUpdateDemo2 
{
	public static void main(String[] args) 
	{
		Connection con=null;
		PreparedStatement pst=null;
		Scanner sc=sc=new Scanner(System.in);
		int dataUpdated=0;
		System.out.println("Enter the no of recors you want to Update");
		int noOfRecords=sc.nextInt();
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
		} 
		catch (Exception e1) 
		{			
			e1.printStackTrace();
		}
		String UpdateQry="UPDATE emp_142270 SET emp_sal=emp_sal+10000 WHERE emp_sal>35000 and emp_id=?";
		for(int i=0;i<noOfRecords;i++)
		{			
			System.out.println("Enter Employee Id of the record which you want to Update:");
			int empId=sc.nextInt();

			try 
			{
				pst=con.prepareStatement(UpdateQry);
				pst.setInt(1, empId);
				dataUpdated=pst.executeUpdate();
			} 
			catch (Exception e) 
			{					
				e.printStackTrace();
			}
		}
		System.out.println("Data Updated ");
	}
}
