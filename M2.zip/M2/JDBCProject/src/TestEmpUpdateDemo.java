import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class TestEmpUpdateDemo 
{
	public static void main(String[] args) 
	{
		Connection con=null;
		PreparedStatement pst=null;
		
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			String updateQry="UPDATE emp_142270 SET emp_sal=emp_sal+10000 WHERE emp_sal>20000";
			pst=con.prepareStatement(updateQry);
			int dataUpdated=pst.executeUpdate();
			System.out.println("Data Updated ");
		} 
		catch (Exception e1) 
		{			
			e1.printStackTrace();
		}
	}
}
