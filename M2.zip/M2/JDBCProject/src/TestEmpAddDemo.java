import java.sql.*;
import java.util.Scanner;

public class TestEmpAddDemo 
{
	public static void main(String[] args) 
	{
		
		Connection con=null;
		PreparedStatement pst=null;
		Statement st=null;
		Scanner sc=sc=new Scanner(System.in);
		int dataAdded=0;
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","Capgemini123");
			st=con.createStatement();
			String insertQry="INSERT INTO emp_142270 VALUES(666,'Raj',7000,'09-DEC-2016')";
			int data=st.executeUpdate(insertQry);
			System.out.println("Data Inserted into table"+data);
		}	
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
}
