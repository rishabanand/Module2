import java.io.*;

public class TestReadWrite 
{
	public static void main(String[] args)
	{
		FileReader fr=null;
		FileWriter fw=null;
		BufferedReader br=null;
		BufferedWriter bw=null;
		StringBuilder sb=null;
		try 
		{
			fr=new FileReader("Date.java");
			br=new BufferedReader(fr);
			System.out.println(br);
			
			
			String st;
			
			while(br.readLine( ) != null) 
			{
			st= br.readLine( );                                     
			sb = new StringBuilder(st);
			sb.reverse();
			//System.out.println(sb);
			st= br.readLine( );
			String st1=new String(sb);
			System.out.println(st1);
			}    

			
			System.out.println("All Data written line by line in the file");
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}

	}

}
