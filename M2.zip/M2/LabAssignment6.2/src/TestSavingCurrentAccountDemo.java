import java.util.Random;
import java.util.regex.Pattern;


public class TestSavingCurrentAccountDemo 
{
	public static void main(String[] args) 
	{
		
		long acno=new Random().nextLong();
		
		Person p3= new Person("Rishab",20.0f);
		SavingAccount s1=new SavingAccount(acno,5000.0,p3);
		System.out.println(s1);
		s1.withdrawal(4600);
		System.out.println("Current balance of Rishab :"+s1.getBalance());

		Person p4= new Person("Divya",20.0f);
		CurrentAccount c1 = new CurrentAccount(acno,70000,p4);
		System.out.println(c1);
		c1.withdrawal(30000);
		System.out.println("Current balance of Divya :"+c1.getBalance());
		
		String AgePattern="[1-9]{1,}";
		Float age= new Float(p4.getAge());
		String  age1 =age.toString();
		Float age2= new Float(p3.getAge());
		String  age3 =age2.toString();
		
		 if(p4.getAge()<15||p3.getAge()<15 ||Pattern.matches(AgePattern, age1)||Pattern.matches(AgePattern, age3))
		{
			try 
			{
				throw new ValidAgeException("Not valid age");
			} 
			catch (ValidAgeException e) 
			{				
				System.out.println("Your age must be above 15 years and Minimum 1 digit must be enetered between 1 to 9");
			}
		}
		 else
			 System.out.println("Valid Age");
	}

}
