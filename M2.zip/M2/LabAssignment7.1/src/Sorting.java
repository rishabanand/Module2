import java.util.Arrays;
import java.util.Scanner;


public class Sorting 
{
	public static void main(String[] args) 
	{
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the total number of names :");
		int totalNoOfNames = sc.nextInt();
		String names[] = new String[totalNoOfNames];
		System.out.println("Enter the names");
		for(int i=0;i<names.length;i++)
		{
			names[i] = sc.next();
		}
		System.out.println("Before Sorting :");
		System.out.println("***************");
		for(int i=0;i<names.length;i++)
		{
			System.out.println(names[i]);
		}
		Arrays.sort(names);
		System.out.println(" ");
		System.out.println("After the sorting");
		System.out.println("***************");
		for(int i = 0;i<names.length;i++)
		{
			System.out.println(names[i]);
		}
	}
}
