
public class TestPerson2Info 
{
	public static void main(String[] args) 
	{
		Person2 p = new Person2("Divya","Bharti",'F',"9906201528");
		p.displayPerson2();
	}
}
