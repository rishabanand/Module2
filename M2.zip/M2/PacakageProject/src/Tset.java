
public class Tset {

	public static void main(String[] args) {
	
	}
}
