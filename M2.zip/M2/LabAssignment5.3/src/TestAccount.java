
public class TestAccount
{
	public static void main(String[] args) 
	{
		Withdraw w1=new Withdraw();
		w1.setAccNum(11111111);
		w1.setBalance(50000);
		Person p=new Person("Rishab",20);
		w1.setAccHolder(p);
		w1.withdrawal(2000);
		
		System.out.println("Current Blance :"+w1.toString());
	}

}
