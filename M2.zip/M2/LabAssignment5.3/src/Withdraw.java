
public class Withdraw extends Account
{
	@Override
	public  void withdrawal(double withdrawalAmt)
	{
		double balance= super.getBalance();
		 balance=balance-withdrawalAmt;
		 super.setBalance(balance);
		 
	}
}
