
public class Number 
{
	public static void main(String[] args) 
	{
		int number = Integer.parseInt(args[0]);
		if ( number > 0 )
		{
			System.out.println("Number is Positive");
		}
		else if( number < 0)
		{
			System.out.println("Number is neagtive");
		}
		else
		{
			System.out.println("Number is zero");
		}
	}
}
