
import java.io.*;

public class TestReadEvenNumbers 
{
	public static void main(String[] args)
	{
		InputStreamReader isr=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(isr);
		try 
		{
			int arr[]=new int[11];
			System.out.println("Enter 0 to 10 numbers");
			for(int i=0;i<arr.length;i++)
			{
				arr[i]=Integer.parseInt(br.readLine());
			}
			FileWriter fw=new FileWriter("number.txt");
			BufferedWriter bw=new BufferedWriter(fw);

			bw.write("Even numbers  are : ");
			for(int j=0;j<arr.length;j++)
			{
				if(arr[j]%2==0)
				{
					bw.write(+arr[j]+",");
					bw.flush();
				}
			}
			System.out.println("Emp Infop written in a file");
		} 
		catch (IOException ie)
		{
			ie.printStackTrace();
		}
	}

}