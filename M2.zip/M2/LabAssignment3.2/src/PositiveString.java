import java.util.Arrays;


public class PositiveString 
{
	public static String sortString(String inputString)
    {
        char tempArray[] = inputString.toCharArray();
         Arrays.sort(tempArray);
        return new String(tempArray);
    }
	public static void main(String[] args) 
	{
		String inputString = "ANT";
        String outputString = sortString(inputString);
             
        System.out.println("Output String : " + outputString);
        if(outputString.equals(inputString))
        {
        	System.out.println("The String is positive");
        }
        else 
        	System.out.println("The String is not negative");
    }
}


