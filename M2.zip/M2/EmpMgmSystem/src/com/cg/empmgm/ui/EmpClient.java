package com.cg.empmgm.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.empmgm.service.EmpService;
import com.empmgm.service.EmpServiceImpl;

public class EmpClient 
{
	static Scanner sc=null;
	static EmpService empSer=null;
	public static void main(String[] args) 
	{
		empSer=new EmpServiceImpl();
		sc=new Scanner(System.in);
		int choice=0;
		while(true)
		{
			System.out.println("What Do You Want To Do? ");
			System.out.println("1:Add Employee\t2:Fetch All Emp\t"
					+ "3:Delete Emp\t4:Update Emp\t5:Exit");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: 
				insertEmp();
				break;
			case 2:
				fetchAllEmp();
				break;
			case 3:
				deleteEmp();
				break;
			case 4:
				updateEmp();
				break;
			default: System.exit(0);
			}
		}
	}
	/*********************Main Ends**************************/
	public static void insertEmp()
	{
		System.out.println("Enter Employee Name:");
		String enm=sc.next();
		float esl=0.0f;
		try
		{
			if(empSer.validateName(enm))
			{
				System.out.println("Enter Salary :");
				esl= sc.nextFloat();
				Employee ee=new Employee();
				ee.setEmpName(enm);
				ee.setEmpSal(esl);

				int dataAdded=empSer.addEmp(ee);
				if(dataAdded==1)
				{
					System.out.println("Employee Data Added");
				}
				else
				{
					System.out.println("May some Exception while addition");
				}
			}
		} 
		catch (EmployeeException e) 
		{
			System.out.println(e.getMessage());
		}
	}
	public static void fetchAllEmp()
	{
		try 
		{
			ArrayList<Employee> empList=empSer.getALLEmp();
			for(Employee ee:empList)
			{
				System.out.println(ee);
			}
		} 
		catch (EmployeeException e)
		{
			System.out.println("May some Exception while addition");
		}
	}
	public static void deleteEmp()
	{

	}
	public static void updateEmp()
	{

	}
}
