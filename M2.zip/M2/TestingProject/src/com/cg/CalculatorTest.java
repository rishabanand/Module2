package com.cg;

import org.junit.*;

public class CalculatorTest
{
	static Calculator cc=null;
	@BeforeClass
	public static void calcBeforeClass()
	{
		cc=new Calculator();
		System.out.println("This function is invoked by"
				+ "jUnit runner only once before the execution");
	}
	@AfterClass
	public static void calcAfterClass()
	{
		System.out.println("This function is invoked by jUnit runner"
				+ "only once after the exceution of all test cases");
	}
	@Before
	public  void calcBefore()
	{
		System.out.println("This function is invoked by jUnit runner only once "
				+ "before the execution of each test case");
	}
	@After
	public void calcAfter()
	{
		System.out.println("This function is invoked by jUnit runner"
				+ "only once after the exceution of each test cases");
	}
	@Test
	public void testDivide1()
	{
		Assert.assertEquals(2,cc.divide(50));
	}
	@Test
	public void testDivide2()
	{
		Assert.assertEquals(6,cc.divide(100));
	}
	@Test
	public void testDivide3()
	{
		Assert.assertEquals(-100,cc.divide(-1));
	}
	@Test(expected=ArithmeticException.class)
	public void testDivide4()
	{
		Assert.assertEquals(1,cc.divide(0));
	}
}
