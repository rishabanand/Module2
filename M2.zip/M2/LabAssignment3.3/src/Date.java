import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Date
{		
	public void   displayDate(LocalDate date)
	{
		LocalDate today=LocalDate.now();
		//LocalDate myDOJ=LocalDate.of(2013,12,13);
		Period period=Period.between(date,today);

		int years=period.getYears();
		int months=period.getMonths();
		int day=period.getDays();
		System.out.println("My Experience In Cg Is :"+years+"Years"+months+"Months"+day+"Days ");
	}

	public static void main(String[] args) 
	{
		Date d=new Date();
		Scanner sc=new Scanner(System.in);
		//String dateStr=sc.next();
		String dateStr="28-Sep-2013";
		DateTimeFormatter formatter_1=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate localDate_1= LocalDate.parse(dateStr,formatter_1);
		d.displayDate(localDate_1);

	}
}
