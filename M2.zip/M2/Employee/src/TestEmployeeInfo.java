import java.util.Scanner;


public class TestEmployeeInfo
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of Employees");
		int noOfEmployees = sc.nextInt();
		Employee employees[] = new Employee[noOfEmployees];
		int empId = 0,empSal = 0;
		String empName=null;
		String temp;
		char gen;
		for(int i=0;i<employees.length;i++)
		{
			System.out.println("Enter your Id :");
			empId= sc.nextInt();
			System.out.println("Enter your Name :");
			empName = sc.next();
			System.out.println("Enter Salary :");
			empSal = sc.nextInt();
			System.out.println("Enter your Gender: ");
			temp = sc.next();
			gen = temp.charAt(0);
			employees[i] = new Employee(empId,empName,empSal,gen);
		}
		for(int j=0;j<employees.length;j++)
		{
			System.out.println(employees[j].displayEmployee());
			System.out.println("*********************");
		}
	}

}
