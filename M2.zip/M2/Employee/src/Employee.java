
public class Employee
{
	private int eId;
	private String eName;
	private int eSalary;
	private char eGender;
	
	public Employee()
	{
		eId = 0;
		eName = "unknown";
		eSalary = 0;
		eGender = ' ';
		//System.out.println("Empty constructor called");
	}
	public Employee(int eId,String eName,int eSalary,char eGender)
	{
		//this();
		this.eId = eId;
		this.eName = eName;
		this.eSalary = eSalary;
		this.eGender = eGender;
	}
	public String displayEmployee()
	{
		return "Employee Id :"+eId+"\nEmployee Name:"+eName+"\nEmployee Salary"
				+eSalary+"\nGender"+eGender;
	}
}
