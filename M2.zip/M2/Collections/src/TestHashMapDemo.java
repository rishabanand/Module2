import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;


public class TestHashMapDemo 
{
	public static void main(String[] args)
	{
		HashMap<Long,String> mobileDirectory=new HashMap<Long,String>();
		mobileDirectory.put(8888108810L, "Rishab");
		mobileDirectory.put(9860450830L, "Divya");
		mobileDirectory.put(9608450830L, "Shushant");
		mobileDirectory.put(77545453234L, "Priyanka");
		mobileDirectory.put(8888108810L, "Raj");
		Set<Entry<Long,String>> setIt=mobileDirectory.entrySet();
		//entry set is giving set i.e converting hashMap is converting into set
		Iterator<Entry<Long,String>> mobIt=setIt.iterator();
		
		while(mobIt.hasNext())
		{
			Entry<Long,String> dirEntry=mobIt.next();
			System.out.println("Mobile:"+dirEntry.getKey());
			System.out.println("Name:"+dirEntry.getValue());
			
		}
		
	}
}
