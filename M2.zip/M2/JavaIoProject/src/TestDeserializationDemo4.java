import java.io.*;

public class TestDeserializationDemo4
{
	
	public static void main(String[] args) 
	{
		
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try 
		{
			fis=new FileInputStream("EmpData.obj");
			ois=new ObjectInputStream(fis);
		}
		catch (Exception e) 
		{			
			e.printStackTrace();
		}
		try 
		{
			while(ois.available()>0)
			{
				try 
				{
					Emp e1=(Emp)ois.readObject();
					System.out.println("Employee Info is :"+e1);
				} 
				catch (Exception e2) 
				{
					e2.printStackTrace();
				}
			}
		} 
		catch (IOException e)
		{			
			e.printStackTrace();
		}
	}
}
