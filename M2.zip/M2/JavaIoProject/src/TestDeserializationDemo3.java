import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class TestDeserializationDemo3 
{
	public static void main(String[] args) 
	{
		FileInputStream fis=null;
		ObjectInputStream ois=null;
		try 
		{
			fis=new FileInputStream("EmpData.obj");
			ois=new ObjectInputStream(fis);
		} 
		catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		
		for(int i=0;i<3;i++)
		{
			try 
			{
				Emp e1=(Emp)ois.readObject();
				System.out.println("Employee Info is :"+e1);
			} 
			catch (Exception e2) 
			{
				e2.printStackTrace();
			}
		}
	}
}
