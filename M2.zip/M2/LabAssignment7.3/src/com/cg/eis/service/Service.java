package com.cg.eis.service;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import com.cg.eis.bean.*;

public class Service 
{
	int choice=0;
	HashMap<String,Employee> list = new HashMap<String,Employee>();
	Employee e1=null;

	public void addEmployee(Employee emp) 
	{
		Integer eId=new Integer(emp.getEmpId());
		String id=eId.toString();
		list.put(id,emp);
		System.out.println("Employee Added");
	}
	public void getEmpByInsu(String insuranceScheme)
	{	
		Collection c = list.values();
		Iterator<Employee> it=c.iterator();
		while(it.hasNext())
		{
			Employee e=it.next();
			if(e.getInsuScheme().equals(insuranceScheme))
			{
				System.out.println("Employee Details are :"+e);
			}
		}
	}
	public boolean deleteEmployeeById(int id) 
	{
		list.remove(id);
		return true;
	}
}
