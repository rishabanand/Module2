package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.bean.*;

public class TestEmp extends Employee
{
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Scheme");
		String insc=sc.next();
		Employee e1 = null;
		if(e1.getInsuScheme().equals("SchemeA"))
		{
			System.out.println("Employee Designation Manager");
			System.out.println("Employee Salary is greater than 40000");
		}
		else if(e1.getInsuScheme().equals("SchemeB"))
		{
			System.out.println("Employee Designation Programmer");
			System.out.println("Employee Salary is between 20000 and 40000");
		}
		else if(e1.getInsuScheme().equals("SchemeC"))
		{
			System.out.println("Employee Designation is System Associate");
			System.out.println("Employee Salary is between 5000 and 20000");
		}
		else 
		{
			System.out.println("Employee Designation is Clerk");
			System.out.println("Employee Salary is less than 5000");
		}

	}

}
