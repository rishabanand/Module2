import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;


public class TestDateDemo 
{
	public static void main(String[] args) 
	{
		LocalDate today=LocalDate.now();
		System.out.println("Today date :"+today);
		System.out.println("**************");
		LocalDate myDOJ=LocalDate.of(2013,12,13);
		System.out.println("My date of Join:"+myDOJ);
		System.out.println("*************");
		String rishabDOJ="13-Dec-2017";
		DateTimeFormatter myFormat =DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		LocalDate rishabDojD=LocalDate.parse(rishabDOJ, myFormat);
		System.out.println("Rishab Doj:"+rishabDojD);
		
		System.out.println("*****************************");
		DateTimeFormatter secondFormat=DateTimeFormatter.ofPattern("yyyy-MMM-dd");
		String urDOJ=rishabDojD.format(secondFormat);
		System.out.println("..."+urDOJ);
		
		System.out.println("Difference Between two dates");
		Period period=Period.between(myDOJ,today);
		int years=period.getYears();
		int months=period.getMonths();
		int day=period.getDays();
		System.out.println("My Experience In Cg Is :"+years+"Years"+months+"Months"+day+"Days ");
	}

}
