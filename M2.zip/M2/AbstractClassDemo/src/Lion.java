
public class Lion extends Animal
{

	public static void main(String[] args) 
	{
		Animal a1=null;
		a1=new Lion();
		a1.sound();
		
	}

	@Override
	public void sound() 
	{
		System.out.println("Roar");
		
	}

}
