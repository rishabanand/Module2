
public abstract class Animal 
{
	public abstract void sound();

	public Animal() 
	{
		super();
		
	}
	
}
