enum SEASONS
{
	SUMMER,RAINY,WINTER;
}
enum Coin
{
	PENNY(1),NICKEL(5),DICE(10),QUARTER(4);
	private final int value;
	private Coin(int value)
	{
		this.value=value;
	}
	 public int value()
	{
		return value;
	}
}
public class TestEnumDemo 
{
	public static void main(String[] args) 
	{
		SEASONS currentSeason = SEASONS.WINTER;
		System.out.println("Its "+currentSeason);
		
		Coin myCoins = Coin.NICKEL;
		System.out.println("I have :"+myCoins);
		System.out.println(myCoins +"has a value of :"+myCoins.value());
	}
}
