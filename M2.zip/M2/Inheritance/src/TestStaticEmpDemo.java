
public class TestStaticEmpDemo
{
	static 
	{
		System.out.println("This is TestStaticDemo static block");
	}
	public static  void hello()
	{
		System.out.println("This is a static function of TestStaticEmpDemo class");
	}
	public static void main(String[] args) 
	{
		System.out.println("Main starts here");
		Emp e1 = new Emp(111,"Rishab",1000.0f);
		Emp e2 = new Emp(222,"Divya",2000.0f);
		Emp e3 = new Emp(333,"Shushant",3000.0f);
		System.out.println(e1.disEmpInfo());
		System.out.println(e2.disEmpInfo());
		System.out.println(e3.disEmpInfo());
		Emp.getCount();
		hello();
	}
}
