import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;


public class TestWriteDataProperty 
{
	public static void main(String[] args) 
	{
		FileWriter fw=null;
		Properties pw=null;
		try 
		{
			 fw=new FileWriter("PersonProps.properties");
			 pw=new Properties();
			 pw.setProperty("personName", "Rishab");
			 pw.setProperty("personId", "142270");
			 pw.setProperty("personUserName", "risanand");
			 pw.setProperty("personPassword", "abc@");
			 pw.store(fw, "This is Oracle DB creadialtis");
			 System.out.println("Data written in prop file");
		} 
		catch (IOException e) 
		{			
			e.printStackTrace();
		}

	}

}
