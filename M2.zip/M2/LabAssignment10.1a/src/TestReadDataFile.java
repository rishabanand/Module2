import java.io.*;
import java.util.Properties;
public class TestReadDataFile 
{
	public static void main(String[] args) 
	{
		FileReader fr=null;
		Properties props=null;
		try 
		{
			 fr=new FileReader("PersonProps.properties");
			 props=new Properties();
			 props.load(fr);//function to read property without comment and loading the value 
			 				//from reader
			 System.out.println("***********all data*********");
			 System.out.println(props);
			 
				
		} 
		catch (IOException e) 
		{			
			e.printStackTrace();
		}
	}

}
