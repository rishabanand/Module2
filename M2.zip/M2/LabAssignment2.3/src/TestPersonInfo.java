
public class TestPersonInfo
{
	public static void main(String[] args)
	{
		Person1 p1 = new Person1("Divya","Bharti",'F');
		
		System.out.println(" First Name :"+p1.getFirstName());
		System.out.println(" Last Name :"+p1.getLastName());
		System.out.println(" Gender :"+p1.getGender());
	}
}
