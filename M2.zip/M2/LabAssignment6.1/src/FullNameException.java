
public class FullNameException extends Exception
{
	public FullNameException(String msg)
	{
		super(msg);
	}
}
