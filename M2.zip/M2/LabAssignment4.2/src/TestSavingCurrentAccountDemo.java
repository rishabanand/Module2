import java.util.Random;


public class TestSavingCurrentAccountDemo 
{
	public static void main(String[] args) 
	{
		Person p1 = new Person("Smith",20.0f);
		long acno=new Random().nextLong();
		
		Person p3= new Person("Rishab",20.0f);
		SavingAccount s1=new SavingAccount(acno,5000.0,p3);
		System.out.println(s1);
		s1.withdrawal(4600);
		System.out.println("Current balance of Rishab :"+s1.getBalance());

		Person p4= new Person("Divya",20.0f);
		CurrentAccount c1 = new CurrentAccount(acno,70000,p4);
		System.out.println(c1);
		c1.withdrawal(30000);
		System.out.println("Current balance of Divya :"+c1.getBalance());

	}

}
