public class Syrup extends Medicine
{
	public Syrup() 
	{
		super();
	}
	public Syrup(String medName, String compName, String expireDate,
			float price)
	{
		super(medName,compName,expireDate,price);
	}
	public String disMedicineInfo()
	{
		return super.disMedicineInfo()+"Shake well Before use";
	}
}
