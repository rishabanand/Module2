


public class Medicine 
{
	private String medName;
	private String compName;
	private String expireDate;
	private float price;
	public Medicine() 
	{
		
	}
	public Medicine(String medName, String compName, String expireDate,
			float price) 
	{
		
		this.medName = medName;
		this.compName = compName;
		this.expireDate = expireDate;
		this.price = price;
	}
	
	public String disMedicineInfo() 
	{
		return "Medicine [medName=" + medName + ", compName=" + compName
				+ ", expireDate=" + expireDate + ", price=" + price + "]";
	}
	

	
	


}
