import java.io.*;
import java.util.Properties;
public class TestReadDataFile 
{
	public static void main(String[] args) 
	{
		FileReader fr=null;
		Properties props=null;
		try 
		{
			 fr=new FileReader("PersonProps.properties");
			 props=new Properties();
			 props.load(fr);//function to read property without comment and loading the value 
			 				//from reader
			 System.out.println("***********all data*********");
			 
			 
				String pnm= props.getProperty("personName");
				String pId= props.getProperty("personId");
				String pUname= props.getProperty("personUserName");
				String pPwd= props.getProperty("personPassword");
				System.out.println("Person Info "+"\nPersonName:"+pnm+" PersonId:"+pId+ "PersonUserName: " +pUname+ "PersonPassword:"+pPwd);
			 
		} 
		catch (IOException e) 
		{			
			e.printStackTrace();
		}
	}
}
