package com.cg.contact.junit;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.contact.dao.ApplyDao;
import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.dao.ApplyDaoImpl;
import com.cg.contact.exception.ApplicantException;


public class ApplyDaoImplTest
{
	static ApplyDao applyDao=null;
	static ApplicantBean applicant=null;
	@BeforeClass
	public static void BeforeClass() throws ApplicantException
	{
		applyDao=new ApplyDaoImpl();
		applicant=new ApplicantBean();
		applicant.setfName("Sanjeev");
		applicant.setlName("Suman");
		applicant.setContactNo(9906201528l);
		applicant.setEmail("sanjeev@gmail.com");
		applicant.setAggregate(80.2f);
		applicant.setStream("ComputerScience");
		
	}
	@Test
	public  void testAddApplicantDetails() throws ApplicantException
	{
		Assert.assertEquals(1, applyDao.addApllicantDetails(applicant));
	}
	@Test 
	public void testGetAllMobileDetail() throws ApplicantException
	{		
		Assert.assertNotNull(applyDao.getApplicantDetails(applyDao.generateApplyId()));
	}
}
