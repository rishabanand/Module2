package com.cg.contact.service;

import com.cg.contact.bean.ApplicantBean;
import com.cg.contact.exception.ApplicantException;

public interface ApplyService 
{
	public int addApllicantDetails(ApplicantBean applicant)throws ApplicantException;
	public ApplicantBean getApplicantDetails(long applicantId) throws ApplicantException;
	public int generateApplyId() throws ApplicantException;
	
	public boolean isValidApplicant(ApplicantBean applicant)throws ApplicantException;
	
}
